# GoDark JavaScript SDK

Encrypted JavaScript / TypeScript client for the GoDark DEX.

## Endpoints

The trading WebSocket lives at `/ws/v1`. The SDK appends this suffix to whatever
base URL it is given (and upgrades a legacy `/ws` to `/ws/v1` automatically).

Canonical hosts (per the public docs):

- Mainnet: `wss://api.godarkdex.com/ws/v1`
- Testnet: `wss://api.godarkdex-testnet.com/ws/v1`

The default base URL is unchanged; localnet / dev usage continues to work via
`GODARK_EDGE_URL` / `GDX_EDGE_URL` env overrides (e.g. `ws://localhost:4000`).

The market-data feed keeps its own path at `/ws/gomarket` and is not affected
by the `/ws/v1` change.

## Quickstart

**From the `gdx` meta-repo** (recommended): clone `gdx` with `--recurse-submodules`. This SDK
lives at `gdx-sdk/gdx-js-sdk/`; `gdx-proto` is a symlink to the umbrella’s `gdx-proto` submodule
(`../../gdx-proto`), same pattern as `gdx-core` / `gdx-wire`.

**Standalone clone:** the repo ships that symlink; it only resolves inside the meta-repo layout.
For a checkout of this repo alone, replace it with a real `gdx-proto` tree:

```bash
git clone <repo-url> gdx-js-sdk
cd gdx-js-sdk
rm gdx-proto && git clone https://github.com/gq-godark/gdx-proto.git gdx-proto
npm ci
npm test
```

## Quickstart

Set `GODARK_API_KEY_ID`, `GODARK_API_SECRET`, and `GODARK_PASSPHRASE` (legacy `GDX_*` aliases accepted) before using key-pair auth. Legacy localnet static keys (e.g. `test-key-1`) do not require a passphrase.

## Build

```bash
npm run build       # tsup ESM/CJS/DTS
```

## Layout

- `src/`          — package source (TypeScript)
- `tests/`        — vitest suites
- `examples/`    — runnable examples
- `scripts/`      — verify scripts (`verify_all.sh`)
- `shared/`       — vendored symbol map (canonical copy lives in gdx-proto repo)
- `gdx-proto/`    — symlink to umbrella `gdx-proto` in the meta-repo; or a `gdx-proto` clone when developing standalone (see Quickstart)
