# GoDark JavaScript SDK

Encrypted JavaScript / TypeScript client for the GoDark DEX.

## Endpoints

The trading WebSocket lives at `/ws/v1`. The SDK appends this suffix to whatever
base URL it is given (and upgrades a legacy `/ws` to `/ws/v1` automatically).

Canonical hosts (per the public docs):

- Mainnet: `wss://api.godarkdex.com/ws/v1`
- Testnet: `wss://api.godarkdex-testnet.com/ws/v1`

The default base URL is unchanged; localnet / dev usage continues to work via
`GODARK_EDGE_URL` / `GDX_EDGE_URL` env overrides (e.g. `ws://localhost:4000`).

The market-data feed keeps its own path at `/ws/gomarket` and is not affected
by the `/ws/v1` change.

## Quickstart

**From the `gdx` meta-repo** (recommended): clone `gdx` with `--recurse-submodules`. This SDK
lives at `gdx-sdk/gdx-js-sdk/`; `gdx-proto` is a symlink to the umbrella’s `gdx-proto` submodule
(`../../gdx-proto`), same pattern as `gdx-core` / `gdx-wire`.

**Standalone clone:** the repo ships that symlink; it only resolves inside the meta-repo layout.
For a checkout of this repo alone, replace it with a real `gdx-proto` tree:

```bash
git clone <repo-url> gdx-js-sdk
cd gdx-js-sdk
rm gdx-proto && git clone https://github.com/gq-godark/gdx-proto.git gdx-proto
npm ci
npm test
```

## Quickstart

Set `GODARK_API_KEY_ID`, `GODARK_API_SECRET`, and `GODARK_PASSPHRASE` (legacy `GDX_*` aliases accepted) before using key-pair auth. Legacy localnet static keys (e.g. `test-key-1`) do not require a passphrase.

Encrypted WebSocket trading also requires the sequencer Noise XK static public key (`noiseStaticPublicKeyHex` on the client config, or `GDX_NOISE_STATIC_PUBLIC_KEY` / `GDX_NOISE_STATIC_PUBKEY`). The client runs a `Noise_XK_25519_AESGCM_SHA256` handshake after login; legacy ECDH `session.setup` is no longer used.

## Place order lifecycle (fast-ack)

`placeOrder` uses the sequencer **fast-ack** path:

1. **Ack** — risk-validated accept with an `order_id` (not yet proof the order rested).
2. **Outcome** — a later order update: `OPEN` / `FILLED` / `PARTIALLY_FILLED` / `CANCELLED`, or `REJECTED`.

By default, `placeOrder` uses `confirmation: 'book'`: it waits for that definitive
update before resolving. On `REJECTED` it throws `OrderError` with the wire code
and `msg` / reject text when present.

Market makers that manage the push stream themselves can explicitly select the
fast acknowledgement boundary:

```ts
await client.placeOrder({ ...order, confirmation: 'ack' });
```

An ACK means the order was acknowledged and assigned an `order_id`; it does not
mean the order rested. With `confirmation: 'ack'`, consume `onOrderUpdate` or
`orderUpdates` to observe the later `OPEN`, fill, cancellation, or `REJECTED`.
Use `placeOrderTerminalTimeoutMs` to configure only the `"book"` confirmation
deadline.

Cancel on an order that never rested should return `ORDER_NOT_FOUND` (2003), not `INTERNAL_ERROR`.

## Build

```bash
npm run build       # tsup ESM/CJS/DTS
```

## Layout

- `src/`          — package source (TypeScript)
- `tests/`        — vitest suites
- `examples/`    — runnable examples
- `scripts/`      — verify scripts (`verify_all.sh`)
- `shared/`       — vendored symbol map (canonical copy lives in gdx-proto repo)
- `gdx-proto/`    — symlink to umbrella `gdx-proto` in the meta-repo; or a `gdx-proto` clone when developing standalone (see Quickstart)
