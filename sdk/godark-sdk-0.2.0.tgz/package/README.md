# GoDark JavaScript SDK

Encrypted JavaScript / TypeScript client for the GoDark DEX.

## Endpoints

The trading WebSocket lives at `/ws/v1`. The SDK appends this suffix to whatever
base URL it is given (and upgrades a legacy `/ws` to `/ws/v1` automatically).

| Environment | Canonical URL | HPKE pin |
|---|---|---|
| Testnet (default) | `wss://api.godark-dex.com/ws/v1` | baked in (testnet pin) |
| Devnet | `wss://api.devnet.godark-dex.com/ws/v1` | baked in (devnet pin; distinct from Testnet) |
| Localnet | `ws://127.0.0.1:4000/ws/v1` | set via config / env |

```ts
import { Environment, GodarkClient } from '@godark/sdk';

const client = new GodarkClient({
  environment: Environment.Testnet, // default; sets URL + HPKE pin
  apiKeyId: 'gdk_...',
  apiSecret: '...',
  passphrase: '...',
});
```

Preference order for URL: `baseUrl` → `GODARK_EDGE_URL` / `GDX_EDGE_URL` →
environment preset. Preference order for the HPKE pin:
`hpkeStaticPublicKeyHex` → `GDX_HPKE_STATIC_PUBLIC_KEY` (aliases) → baked-in
pin from `environment`.

Public mainnet is not currently exposed; testnet is the live network for SDK
users today. The market-data feed keeps its own path at `/ws/gomarket`.

## Quickstart

**Standalone clone:** committed bindings in `src/generated` are enough to test.

```bash
git clone <repo-url> gdx-js-sdk
cd gdx-js-sdk
npm ci
npm test
```

**From the `gdx` meta-repo:** clone `gdx` with `--recurse-submodules`. This SDK
lives at `gdx-sdk/gdx-js-sdk/`. Proto codegen walks up to the umbrella
`gdx-proto` submodule (or uses `GDX_PROTO_ROOT`).

## Quickstart

Set `GODARK_API_KEY_ID`, `GODARK_API_SECRET`, and `GODARK_PASSPHRASE` (legacy `GDX_*` aliases accepted) before using key-pair auth. Legacy localnet static keys (e.g. `test-key-1`) do not require a passphrase.

Encrypted WebSocket trading uses HPKE after login. On Testnet and Devnet
the sequencer public pin for that environment is baked into the SDK (pins are
not shared across environments); override with `hpkeStaticPublicKeyHex` or
`GDX_HPKE_STATIC_PUBLIC_KEY` / `GDX_HPKE_STATIC_PUBKEY` when needed
(required for Localnet).

## Place order lifecycle (fast-ack)

`placeOrder` uses the sequencer **fast-ack** path:

1. **Ack** — risk-validated accept with an `order_id` (not yet proof the order rested).
2. **Outcome** — a later order update: `OPEN` / `FILLED` / `PARTIALLY_FILLED` / `CANCELLED`, or `REJECTED`.

By default, `placeOrder` uses `confirmation: 'book'`: it waits for that definitive
update before resolving. On `REJECTED` it throws `OrderError` with the wire code
and `msg` / reject text when present.

Market makers that manage the push stream themselves can explicitly select the
fast acknowledgement boundary:

```ts
await client.placeOrder({ ...order, confirmation: 'ack' });
```

An ACK means the order was acknowledged and assigned an `order_id`; it does not
mean the order rested. With `confirmation: 'ack'`, consume `onOrderUpdate` or
`orderUpdates` to observe the later `OPEN`, fill, cancellation, or `REJECTED`.
Use `placeOrderTerminalTimeoutMs` to configure only the `"book"` confirmation
deadline.

Cancel on an order that never rested should return `ORDER_NOT_FOUND` (2003), not `INTERNAL_ERROR`.

## Build

```bash
npm run build       # tsup ESM/CJS/DTS
```

## Layout

- `src/`          — package source (TypeScript)
- `tests/`        — vitest suites
- `examples/`    — runnable examples
- `scripts/`      — `proto_gen.sh` / `resolve-proto.sh`
- `shared/`       — vendored symbol map (canonical copy lives in gdx-proto repo)
- `src/generated/` — committed protobuf bindings
